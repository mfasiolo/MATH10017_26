#include <stdio.h>

int main(void){
    int n = 10;
    int previous = 0;
    int current = 1;

    printf("%d %d ", previous, current);

    for(int i = 2; i <= n; i++){
        // 1. Compute the next Fibonacci number.

        // 2. Print the next Fibonacci number.

        // 3. Update previous and current.
    }

    printf("\n");

    // What is the time complexity of this algorithm?

    return 0;
}
