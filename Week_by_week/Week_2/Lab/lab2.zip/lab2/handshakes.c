#include <stdio.h>

int main(void){
    int n = 4;
    int total = 0;

    // Use nested loops to print every pair and update total.

    printf("Total: %d\n", total);

    // What is the time complexity of this algorithm?

    return 0;
}
