#include <stdio.h>

int range(const double values[], int length,
          double *minp, double *maxp)
{
    // TODO: check the length and all three pointers before dereferencing them.

    // TODO: find the two values and write them through minp and maxp.

    return 0;
}

void swap_min_max(double values[], int length)
{
    // TODO: make minimum and maximum point to elements of values.

    // TODO: scan the array, then swap the two pointed-to values.
}

void print_array(const double values[], int length)
{
    // TODO: Write a function to print the elements of an array
}

void swap(double *left, double *right)
{
    // TODO: swap the values stored at the two addresses.
}

void bubble_sort(double values[], int length)
{
    // TODO: repeat the scan length - 1 times.

    // TODO: compare neighbouring elements and use swap when needed.
}

int main(void)
{
    double observations[] = {4.2, -1.0, 3.8, 7.1, 2.4};
    int length = 5;

    double minimum;
    double maximum;

    int success = range(observations, length, &minimum, &maximum);
    
    // Question, what is the point of checking success == 1? 
    if ( success == 1) {
        printf("Minimum: %.2f\n", minimum);
        printf("Maximum: %.2f\n", maximum);
    } else {
        printf("The range could not be calculated.\n");
    }

    printf("Before: ");
    print_array(observations, length);

    swap_min_max(observations, length);

    printf("After:  ");
    print_array(observations, length);

    bubble_sort(observations, length);

    printf("Sorted: ");
    print_array(observations, length);

    return 0;
}
