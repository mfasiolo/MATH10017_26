#include <stdio.h>

int range(const double values[], int length,
          double *minimum, double *maximum)
{
    // TODO: check the length and all three pointers before dereferencing them.

    // TODO: find the two values and write them through minimum and maximum.

    return 0;
}

void swap_min_max(double values[], int length)
{
    // TODO: make minimum and maximum point to elements of values.

    // TODO: scan the array, then swap the two pointed-to values.
}

void print_array(const double values[], int length)
{
    for (int i = 0; i < length; i = i + 1) {
        printf("%.2f ", values[i]);
    }
    printf("\n");
}

int main(void)
{
    double observations[] = {4.2, -1.0, 3.8, 7.1, 2.4};
    int length = 5;

    double minimum;
    double maximum;

    if (range(observations, length, &minimum, &maximum)) {
        printf("Minimum: %.2f\n", minimum);
        printf("Maximum: %.2f\n", maximum);
    } else {
        printf("The range could not be calculated.\n");
    }

    printf("Before: ");
    print_array(observations, length);

    swap_min_max(observations, length);

    printf("After:  ");
    print_array(observations, length);

    return 0;
}
