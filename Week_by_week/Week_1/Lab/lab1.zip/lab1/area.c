#include <stdio.h>

//write the calculate_area function below

//write the main function below
int main(void)
{
    printf("modify me\n");
    return 0;
}