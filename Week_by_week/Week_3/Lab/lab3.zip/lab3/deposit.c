# include <stdio.h>

/*
new balance = balance + interest

For year y > 0
balance(y) = balance(y-1) + interest

balance(0) = 900

*/

double balance(int year){
    // write your code here:
}

int main(void){
    printf("Balance after 10 years: £%.2f\n", balance(10));
    return 0;
}
