#include <stdio.h>


int main(void)
{
    double x[ ] = {2.1, 1.8, 2.4, 2.0, 1.7};
    
    const int length = 5;

    // your code here

    return 0;
}

