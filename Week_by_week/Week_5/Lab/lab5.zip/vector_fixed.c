#include <stdio.h>

struct vector {
    int length;
    double elements[3];
};

void print_vector(struct vector v)
{
    // TODO 1: print each element followed by a space.

    printf("\n");
}

double dot(struct vector u, struct vector v)
{
    double total = 0.0;

    // TODO 2: compute the dot product and store it in "total".

    return total;
}

int main(void)
{
    struct vector u;
    struct vector v;
    u.length = 3;
    v.length = 3;

    // TODO 3: initialise u as [1, 2, 3] and v as [4, 5, 6].

    // TODO 4: print u, v and their dot product.

    return 0;
}
