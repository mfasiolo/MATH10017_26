#include <stdio.h>
#include <stdlib.h>

void print_array(const double values[], int length)
{
   
    // TODO 1: print each element followed by a space.
  
    printf("\n");
}

double dot(const double u[], const double v[], int length)
{
    double total = 0.0;

    // TODO 2: compute the dot product and store it in "total".

    return total;
}

int main(void)
{
    int length = 3;
    double *u;
    double *v;

    // TODO 3: allocate two arrays of length doubles for u and for v.

    // TODO 4: initialise u as [1, 2, 3] and v as [4, 5, 6].

    // TODO 5: print u, v and their dot product.

    // TODO 6: release both allocations.

    return 0;
}
