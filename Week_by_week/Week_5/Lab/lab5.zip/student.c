#include <stdio.h>

struct student {
    int id;
    int year;
    double mark;
};

void print_student(struct student s)
{
    // TODO 1: print the id, year and mark.
}

int main(void)
{
    struct student matteo;
    matteo.id = 1024;
    matteo.year = 1;
    matteo.mark = 70.0;


    // TODO 2: create student "ada" using a list initializer, 
    // then print matteo's and ada's details.

    return 0;
}
