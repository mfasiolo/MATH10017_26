#include <stdio.h>
#include <stdlib.h>

struct vector2 {
    int length;
    double *elements;
};

void print_vector2(struct vector2 v)
{
    // TODO 1: print each element followed by a space.

    printf("\n");
}

double dot(struct vector2 u, struct vector2 v)
{
    double total = 0.0;

    // TODO 2: compute the dot product and store it in "total".

    return total;
}

int main(void)
{
    int count;
    printf("Enter a small positive length: ");
    scanf("%d", &count);

    struct vector2 u;
    struct vector2 v;
    u.length = count;
    v.length = count;

    // TODO 3: allocate the element arrays for u and v.

    // TODO 4: initialise the elements of u and v.

    // TODO 5: print u, v and their dot product.

    // TODO 6: release both dynamically allocated arrays.

    return 0;
}
